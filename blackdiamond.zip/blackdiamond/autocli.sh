#!/bin/bash
COUNTER=1
while(true) do
lua5.3 bot.lua
curl "https://api.telegram.org/bot2133186249:AAFXS7KVHj_illrWpfsAC8taww_mMW1SngU/sendMessage" -F "chat_id=229445008" -F "text=BD RoBot Crashed.Wain 15 Sec For Launch Again-${COUNTER}-times"
let COUNTER=COUNTER+1 
done
