#!/usr/bin/env bash
lua api.lua 

