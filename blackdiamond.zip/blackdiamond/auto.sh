#!/bin/bash
COUNTER=1
while(true) do
lua5.3 BDiamond.lua
curl "https://api.telegram.org/bot5227398170:AAG2masPk5OXYWjr85GAUoTkzcvqVPNI_0c/sendMessage" -F "chat_id=229445008" -F "text=BD RoBot Crashed.Wain 15 Sec For Launch Again-${COUNTER}-times"
let COUNTER=COUNTER+1 
done

