do local _ = {
  enabled_plugins = {
    "addrem",
    "bc",
    "supergroup",
    "msg_checks",
    "pin",
    "owner",
    "online",
    "plugins",
    "admin",
    "del",
    "clean",
    "expiretime",
    "filter",
    "setlink",
    "setrules",
    "me",
    "like",
    "rmsg_all",
    "leave"
  },
  group  = {
    data = "bot/group.json"
  },
  sudo_users = {
    1502490631, --sudo ایدی شما
    0,
    0
  },
robot = {
5310557374,--bot ایدی ربات
    0
  }
}
return _
end