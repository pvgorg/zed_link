لطفا با ستاره دادن مارو حمایت کنید
--------------------------------------
## Black_White

- git clone https://github.com/breakheart371/Black_White
- cd Black_White
- sh install
- #edit config.lua, line [28 , 33]
- ./launch.sh
- number
- code
- ctrl + c
- screen ./launch.sh
---------------------------------------
---------------------------------------
## اگر درهنگام ران کردن به ارور برخوردید دستور زیررا ارسال کنید:

- cd Black_White
- killall -9 bash
- screen ./launch.sh
---------------------------------------

##SuperGroup settings

- Lock ➣ Links » yes
- Lock ➣ User » no
- Lock ➣ Edit » no
- Lock ➣ Fwd » no
- Lock ➣ Spam » no
- Lock ➣ Sticker »no
- Lock ➣ Eng » no
- Lock ➣ Far » no
- Lock ➣ Tg » no
- Lock ➣ Tag » no
- Lock ➣ Inline » no
- Lock ➣ Commun » no
- Lock ➣ All » no
- Lock ➣ Text » no
- Lock ➣ Photo » no
- Lock ➣ Video » no
- Lock ➣ Voice » no
- Lock ➣ Doc » no
- Lock ➣ Audio » no
- Lock ➣ Gif » no
- creator: @La_shy
--------------------------------------


